export function getWeather() {
  console.log("Fetching weather data...");
}
