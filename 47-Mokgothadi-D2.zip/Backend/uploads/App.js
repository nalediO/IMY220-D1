console.log("This is App.js for Weather Dashboard");
