console.log("Task Manager main.js loaded");
